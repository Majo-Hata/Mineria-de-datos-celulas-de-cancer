
public class Algortimo_Genetico{
    
    public static void main(String[] args){
        boolean ejecutar = false;
        do{
            try{
                ejecutar = true;
                Algoritmo genAlg = new Algoritmo();
                genAlg.generarPoblacion();
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
        }while (ejecutar==false);
    }
    
}
