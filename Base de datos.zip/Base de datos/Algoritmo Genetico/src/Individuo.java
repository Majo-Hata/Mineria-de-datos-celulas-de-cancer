
public class Individuo{
    
    // Hiperparámetros de Topología  (enteros convertidos a binarios y guardados como cadena)
    private String numNeuronasString;
    private String numCapasOcultasString;
    private String numEpocasString;
    private String learningRateString;
    private String momentumString;
    // Hiperparámetros de Topología  (enteros convertidos a binarios y guardados como cadena)

    // Hiperparámetros de Topología 
    private int numNeuronasInt;
    private int numCapasOcultasInt;
    private int numEpocasInt;
    private double learningRateDouble;
    private double momentumDouble;
    // Hiperparámetros de Topología 

    // Rangos Válidos de la Topología de la Red Neuronal Multicapa Perceptrón 
    private int minNumNeuronas;
    private int maxNumNeuronas;
    private int minNumCapasOcultas;
    private int maxNumCapasOcultas;
    private int minNumEpocas;
    private int maxNumEpocas;
    private double minLearningRate;
    private double maxLearningRate;
    private double minMomentum;
    private double maxMomentum;
    // Rangos Válidos de la Topología de la Red Neuronal Multicapa Perceptrón 

    // Bits utilizados por parámetro; es útil añadir bits adicionales (0s) a las cadenas binarias
    // generadas por Integer.toBinaryString(), ya que no incluye 0s a la izquierda
    private String neuronaBits = "%4s";
    private String capasocultasBits = "%2s";
    private String epocasBits = "%6s";
    private String learningRateBits = "%3s";
    private String momentumBits = "%4s";
    // Bits utilizados por parámetro; es útil añadir bits adicionales (0s) a las cadenas binarias
    // generadas por Integer.toBinaryString(), ya que no incluye 0s a la izquierda

    private double accuracy;
    
    // Constructores
    public Individuo(){
        this.setDefaultRanges();
        this.numNeuronasString = new String();
        this.numCapasOcultasString = new String();
        this.numEpocasString = new String();
        this.learningRateString = new String();
        this.momentumString = new String();
    }

    public Individuo(String numNeuronas, String numCapasOcultas, String numEpocas, String learningRate, String momentum){
        this.setDefaultRanges();
        this.setTopologyBinaryString(numNeuronas, numCapasOcultas, numEpocas, learningRate, momentum);
    }

    public Individuo(int numNeuronas, int numCapasOcultas, int numEpocas, double learningRate, double momentum){
        this.setDefaultRanges();
        this.setTopologyMLP(numNeuronas, numCapasOcultas, numEpocas, learningRate, momentum);
    }

    public Individuo(double accuracy){
        this.setDefaultRanges();
        this.accuracy = accuracy;
    }
    // Constructores

    // Se asignan los valores del número de neuronas, capas ocultas, epocas, learningrate y momento (momentum)
    public void setTopologyMLP(int numNeuronas, int numCapasOcultas, int numEpocas, double learningRate, double momentum){
        this.setnumNeuronasInt(numNeuronas);
        this.setnumCapasOcultasInt(numCapasOcultas);
        this.setnumEpocasInt(numEpocas);
        this.setlearningRateDouble(learningRate);
        this.setMomentumDouble(momentum);
    }
    // Se asignan los valores del número de neuronas, capas ocultas, epocas, learningrate y momento (momentum)
    
    // Se asignan los valores del número de neuronas, capas ocultas, epocas, learningrate y momento (momentum); en binario
    // y formato String
    public void setTopologyBinaryString(String numNeuronas, String numCapasOcultas, String numEpocas, 
            String learningRate, String momentum){
        this.setnumNeuronasString(numNeuronas);
        this.setnumCapasOcultasString(numCapasOcultas);
        this.setnumEpocasString(numEpocas);
        this.setLearningRateString(learningRate);
        this.setMomentumString(momentum);
    }
    // Se asignan los valores del número de neuronas, capas ocultas, epocas, learningrate y momento (momentum); en binario
    // y formato String
    
    // Validar si la secuencia genética de este individuo está dentro del rango previamente especificado de 
    // la topología de la red neuronal, especificados en setDefaultRanges()
    public boolean validate(){
        if (!(numNeuronasInt>=minNumNeuronas && numNeuronasInt<=maxNumNeuronas)){
            return false;
        }
        if (!(numCapasOcultasInt>=minNumCapasOcultas && numCapasOcultasInt<=maxNumCapasOcultas)){
            return false;
        }
        if (!(numEpocasInt>=minNumEpocas && numEpocasInt<=maxNumEpocas)){
            return false;
        }
        if (!(learningRateDouble>=minLearningRate && learningRateDouble<=maxLearningRate)){
            return false;
        }
        if (!(momentumDouble>=minMomentum && momentumDouble<=maxMomentum)){
            return false;
        }
        return true;
    }
    // Validar si la secuencia genética de este individuo está dentro del rango previamente especificado de 
    // la topología de la red neuronal, especificados en setDefaultRanges()

    public String getGeneticSequence(){
        return this.numNeuronasString + this.numCapasOcultasString + this.numEpocasString + this.learningRateString + 
            this.momentumString;
    }

    public String doubleToBinaryString(double number, String numBits){
        int numberInt = (int) number;
        return String.format(numBits, Integer.toBinaryString(numberInt)).replace(' ', '0');
    }
    
    // Definición de los mínimos y máximos de neuronas, capas ocultas, épocas, tasa de aprendizaje y momento (momentum);
    // así como la definición de precisión (accuracy)
    private void setDefaultRanges(){
        this.minNumNeuronas = 2;
        this.maxNumNeuronas = 20;
        this.minNumCapasOcultas = 1;
        this.maxNumCapasOcultas = 5;
        this.minNumEpocas = 1;
        this.maxNumEpocas = 500;
        this.minLearningRate = 0.01;
        this.maxLearningRate = 0.3;
        this.minMomentum = 0.01;
        this.maxMomentum = 0.3;
        this.accuracy = 0.0;
    }
    // Definición de los mínimos y máximos de neuronas, capas ocultas, épocas, tasa de aprendizaje y momento (momentum);
    // así como la definición de precisión (accuracy)
    
    // Métodos setters de los hiperparámetros String
    public void setnumNeuronasString(String numNeuronas){
        this.numNeuronasString = numNeuronas;
        this.numNeuronasInt = Integer.parseInt(numNeuronas, 2) + minNumNeuronas;
    }

    public void setnumCapasOcultasString(String numCapasOcultas){
        this.numCapasOcultasString = numCapasOcultas;
        this.numCapasOcultasInt = Integer.parseInt(numCapasOcultas, 2) + minNumCapasOcultas;
    }

    public void setnumEpocasString(String numEpocas){
        this.numEpocasString = numEpocas;
        this.numEpocasInt = Integer.parseInt(numEpocas, 2) + minNumEpocas;
    }

    public void setLearningRateString(String learningRate){
        this.learningRateString = learningRate;
        this.learningRateDouble = (Double.valueOf(Integer.parseInt(learningRate, 2)) + (minLearningRate*100d))/100d;
    }

    public void setMomentumString(String momentum){
        this.momentumString = momentum;
        this.momentumDouble = (Double.valueOf(Integer.parseInt(momentum, 2)) + (minMomentum*100d))/100d;
    }
    // Métodos setters de los hiperparámetros String
    
    // Métodos setters de los hiperparámetros Int/Double
    public void setnumNeuronasInt(int numNeuronas){
        this.numNeuronasInt = numNeuronas;
        this.numNeuronasString = this.doubleToBinaryString(numNeuronas - minNumNeuronas, neuronaBits);
    }

    public void setnumCapasOcultasInt(int numCapasOcultas){
        this.numCapasOcultasInt = numCapasOcultas;
        this.numCapasOcultasString = this.doubleToBinaryString(numCapasOcultas - minNumCapasOcultas, capasocultasBits);
    }

    public void setnumEpocasInt(int numEpocas){
        this.numEpocasInt = numEpocas;
        this.numEpocasString = this.doubleToBinaryString(numEpocas - minNumEpocas, epocasBits);
    }

    public void setlearningRateDouble(double learningRate){
        this.learningRateDouble = learningRate;
        this.learningRateString = this.doubleToBinaryString(((learningRate*100)-(minLearningRate*100)), learningRateBits);
    }

    public void setMomentumDouble(double momentum){
        this.momentumDouble = momentum;
        this.momentumString = this.doubleToBinaryString(((momentum*100)-(minMomentum*100)), momentumBits);
    }
    // Métodos setters de los hiperparámetros Int/Double

    public void setAccuracy(double accuracy){
        this.accuracy = accuracy;
    }
    
    // Métodos getters de los hiperparámetros String
    public String getnumNeuronasString(){
        return numNeuronasString;
    }

    public String getnumCapasOcultasString(){
        return numCapasOcultasString;
    }

    public String getnumEpocasString(){
        return numEpocasString;
    }

    public String getLearningRateString(){
        return learningRateString;
    }

    public String getMomentumString(){
        return momentumString;
    }
    // Métodos getters de los hiperparámetros String
    
    // Métodos getters de los hiperparámetros Int/Double
    public double getnumNeuronasInt(){
        return numNeuronasInt;
    }

    public double getnumCapasOcultasInt(){
        return numCapasOcultasInt;
    }

    public int getnumEpocasInt(){
        return numEpocasInt;
    }

    public double getlearningRateDouble(){
        return learningRateDouble;
    }
    
    public double getMomentumDouble(){
        return momentumDouble;
    }
    // Métodos getters de los hiperparámetros Int/Double
    
    // Métodos getters de los rangos
    public double getMaxLearningRate(){
        return maxLearningRate;
    }

    public double getMaxMomentum(){
        return maxMomentum;
    }

    public double getMinLearningRate(){
        return minLearningRate;
    }

    public double getMinMomentum(){
        return minMomentum;
    }
    // Métodos getters de los rangos
    
    public double getAccuracy(){
        return accuracy;
    }

    public String getnumCapasOcultasStringMLP(){
        String numCapasOcultasMLP = "";
        for (int i=0; i<this.numCapasOcultasInt; i++){
            numCapasOcultasMLP += Integer.toString(this.numNeuronasInt);
            if (i!=numCapasOcultasInt-1){
                numCapasOcultasMLP += ",";
            }
        }
        return numCapasOcultasMLP;
    }
    
    @Override
    public String toString(){
        return "Binary Strings: " + numNeuronasString + ", " + numCapasOcultasString + ", " + numEpocasString + ", " + 
            learningRateString + ", " + momentumString + ", \n" + "MLP values: " + numNeuronasInt + ", " + 
            numCapasOcultasInt + " ( " + getnumCapasOcultasStringMLP() + " ), " + numEpocasInt + ", " + 
            learningRateDouble + ", " + momentumDouble + ", ";
    }

}

