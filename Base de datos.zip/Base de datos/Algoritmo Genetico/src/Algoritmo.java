import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Instances;
import weka.classifiers.evaluation.Evaluation;
import java.util.Scanner;
import java.io.*;

public class Algoritmo{
    
    private Individuo[] generation;
    // Guarda las parejas a cruzar y los nuevos hijos
    
    private int n;
    // Número de individuos
    
    private FileInputStream entrada;
    // Utilizado para la apertura y cierre de una archivo de texto
    
    private int numGeneracion;
    // Número de generación
    
    private MultilayerPerceptron mlp;
    // Tipo de red neuronal exportado de la biblioteca de weka

    public Algoritmo(String file) throws FileNotFoundException{
        this.entrada = new FileInputStream(file);
        this.generation = new Individuo[50];
        this.n = 13;
        this.mlp = new MultilayerPerceptron();
        this.numGeneracion = 1;
        for(int i=0; i<generation.length; i++){
            generation[i] = new Individuo(0, 0, 0, 0.0, 0.0);
        }
    }

    public Algoritmo() throws FileNotFoundException{
        this.entrada = new FileInputStream("generacion0.txt");
        this.generation = new Individuo[50];
        this.n = 13;
        this.mlp = new MultilayerPerceptron();
        this.numGeneracion = 1;
        for (int i=0; i<generation.length; i++){
            generation[i] = new Individuo(0, 0, 0, 0.0, 0.0);
        }
    }

    // Continuna con la creación de mas generaciones
    public void generarPoblacion(){
        try{
            //Lee la primera población
            if (numGeneracion==1){
                System.out.println("Leyendo primer archivo");
                lectura();
            }
            Scanner input = new Scanner(System.in);
            boolean answ=false;
            //Proceso general de las generaciones
            do{
                seleccionar_parejas();
                training_testing();
                controlPopulation();
                System.out.println("Ordenando poblacion");
                quicksortGeneration(generation,0,this.n-1);
                numGeneracion++;
                creacionArchivo(numGeneracion);
                System.out.println("¿Continuar? \nSi -> Ingresa 'True' \nNo -> Ingresa 'False'");
                answ = input.nextBoolean();
            }while (answ);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
    // Continuna con la creación de mas generaciones

    // Crea los archivos para guardar las generaciones creadas
    public void creacionArchivo(int generacion) throws IOException{
        String nombreFile = "generacion" + String.valueOf(generacion) + ".txt";
        FileOutputStream salida = new FileOutputStream(nombreFile);
        BufferedWriter buf = new BufferedWriter(new OutputStreamWriter(salida));
        buf.write("Neuronas  |  Capas  |  Epocas | Learning Rate | Momentum | Accuracy\n");
        for (int i=0; i<this.n; i++){
            buf.write("    " + Double.toString(generation[i].getnumNeuronasInt()) + "    |    " 
                + Double.toString(generation[i].getnumCapasOcultasInt()) + "   |    " + 
                Integer.toString(generation[i].getnumEpocasInt()) + "  |      " + 
                Double.toString(generation[i].getlearningRateDouble()) + "      |     " + 
                Double.toString(generation[i].getMomentumDouble()) + "   | " + 
                Double.toString(generation[i].getAccuracy()) + "\n");
        }
        double a=0.0;
        double DesviacionEstandar = 0.0;
        double med=0.0;
        for (int i=0; i<30; i++){
            a+=generation[i].getAccuracy();
        }
        med=a/29;
        for (int i=0; i<30; i++){
            DesviacionEstandar  += Math.pow((generation[i].getAccuracy() - med), 2);
        }
        double raiz = DesviacionEstandar / 30;
        double des = Math.sqrt(raiz);
        buf.write("\n");
        buf.write("\n");
        buf.write("\n");
        buf.write("\n");
        buf.write("Estadisticas de la generacion: \n");
        buf.write("Max= "+ generation[0].getAccuracy()+"\n");
        buf.write("Min= "+ generation[29].getAccuracy()+"\n");
        buf.write("Prom= "+ med +"\n");
        buf.write("DS= " + des + "\n");
        buf.close();
        salida.close();
    }
    // Crea los archivos para guardar las generaciones creadas

    // Realiza la lectura del archivo donde guarda la poblacion inicial
    public void lectura() throws IOException{
        BufferedReader buf = new BufferedReader(new InputStreamReader(entrada));
        String linea;
        String aa = buf.readLine();
        for (int i=0; i<n; i++){
            linea = buf.readLine();
            String linea1 = linea.replaceAll("\\|", " ");
            String lineaCorrect = linea1.trim().replaceAll(" +", " ");
            String[] temp = lineaCorrect.split(" ");
            generation[i] = new Individuo(Integer.parseInt(temp[0]), Integer.parseInt(temp[1]), 
            Integer.parseInt(temp[2]), Double.parseDouble(temp[3])/100.0, Double.parseDouble(temp[4])/100.0);
        }
        entrada.close();
    }
    // Realiza la lectura del archivo donde guarda la poblacion inicial

    // Selecciona las parejas, realiza la cruza y los hijos con mutados
    public void seleccionar_parejas(){
        Individuo[][] parejas = new Individuo[15][3];
        for (int i =0; i<15; i++){
            for (int j=0; j<3; j++){
                parejas[i][j] = new Individuo();
            }
        }
        int max = 14; int min = 0; int k=0;
        if (n<30){
            max=14;
        }
        else{
            max=29;
        }
        int random_int;
        System.out.println(parejas.length);
        for (int i=0; i<parejas.length; i++){
            for (int j=0; j<2; j++){
                random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
                if (j==1 && generation[random_int]==parejas[i][0]){
                    j--;
                }
                else{
                    if (generation[random_int].getnumNeuronasInt()!=0){
                        parejas[i][j] = generation[random_int];
                    }
                    else{
                        j--;
                    }
                }
            }
        }
        for (int i=0; i<parejas.length; i++){
            System.out.println("Pareja\n" + "\t"+parejas[i][0] + "\n\t"+parejas[i][1]);
            cruzar(parejas,i);
        }
        Individuo p;
        k = 0;
        while (k<generation.length){
            p = generation[k];
            if (p.getlearningRateDouble()==0.0 && p.getMomentumDouble()==0.0){
                break;
            }
            k++;
        }
        k--;
        int j=0;
        for(int i=k; i<k+parejas.length; i++){
            generation[i] = parejas[j][2];
            j++;
        }
        mutacion(parejas);
    }
    // Selecciona las parejas, realiza la cruza y los hijos con mutados
    
    // Muta a 2 hijos creados de la cruza que se este realizando
    private void mutacion(Individuo[][] parejas){
        Individuo p = new Individuo();
        int n = 0;
        String temp,aux, newString;
        int random_int, random_int2, descriptor;
        int max = 14; int min = 0, rep=-1;
        temp = "";
        aux = "";
        newString = "";
        for (int i=0; i<2; i++){
            do{
                random_int = (int) Math.floor(Math.random() * (max - min + 1) + min);
            } while (rep==random_int);
            descriptor = (int)(Math.random()*5+1);
            switch (descriptor){
                case 1: // Número de neuronas
                    n = parejas[random_int][2].getnumNeuronasString().length();
                    temp = parejas[random_int][2].getnumNeuronasString();
                    random_int2 = (int) (Math.random() * n + 0);
                    if (temp.charAt(random_int2)=='1'){
                        newString = temp.substring(0, random_int2) + '0' + temp.substring(random_int2 + 1);
                    }
                    else{
                        newString = temp.substring(0, random_int2) + '1' + temp.substring(random_int2 + 1);
                    }
                    aux = parejas[random_int][2].getnumNeuronasString();
                    parejas[random_int][2].setnumNeuronasString(newString);
                    break;
                case 2: // Número de capas ocultas
                    n = parejas[random_int][2].getnumCapasOcultasString().length();
                    temp = parejas[random_int][2].getnumCapasOcultasString();
                    random_int2 = (int) (Math.random() * n + 0);
                    if (temp.charAt(random_int2)=='1'){
                        newString = temp.substring(0, random_int2) + '0' + temp.substring(random_int2 + 1);
                    }
                    else{
                        newString = temp.substring(0, random_int2) + '1' + temp.substring(random_int2 + 1);
                    }
                    aux = parejas[random_int][2].getnumCapasOcultasString();
                    parejas[random_int][2].setnumCapasOcultasString(newString);
                    break;
                case 3:// Epocas
                    n = parejas[random_int][2].getnumEpocasString().length();
                    temp = parejas[random_int][2].getnumEpocasString();
                    random_int2 = (int) (Math.random() * n + 0);
                    if (temp.charAt(random_int2)=='1'){
                        newString = temp.substring(0, random_int2) + '0' + temp.substring(random_int2 + 1);
                    }
                    else{
                        newString = temp.substring(0, random_int2) + '1' + temp.substring(random_int2 + 1);
                    }
                    aux = parejas[random_int][2].getnumEpocasString();
                    parejas[random_int][2].setnumEpocasString(newString);
                    break;
                case 4:// LearningRate
                    n = parejas[random_int][2].getLearningRateString().length();
                    temp = parejas[random_int][2].getLearningRateString();
                    random_int2 = (int)(Math.random()*n+0);
                    if (temp.charAt(random_int2)=='1'){
                        newString = temp.substring(0, random_int2) + '0' + temp.substring(random_int2 + 1);
                    }
                    else{
                        newString = temp.substring(0, random_int2) + '1' + temp.substring(random_int2 + 1);
                    }
                    aux = parejas[random_int][2].getLearningRateString();
                    parejas[random_int][2].setLearningRateString(newString);
                    break;
                case 5:// Momento (Momentum)
                    n = parejas[random_int][2].getMomentumString().length();
                    temp = parejas[random_int][2].getMomentumString();
                    random_int2 = (int)(Math.random()*n+0);
                    if (temp.charAt(random_int2)=='1'){
                        newString = temp.substring(0, random_int2) + '0' + temp.substring(random_int2 + 1);
                    }
                    else{
                        newString = temp.substring(0, random_int2) + '1' + temp.substring(random_int2 + 1);
                    }
                    aux = parejas[random_int][2].getMomentumString();
                    parejas[random_int][2].setMomentumString(newString);
                    break;
                default:
                    System.out.println("ERROR");
                    break;
            }
            //Reasigna el atributo original si la mutación no ocurrió correctamente
            if (!parejas[random_int][2].validate()){
                switch (descriptor){
                    case 1:
                        parejas[random_int][2].setnumNeuronasString(aux);
                        break;
                    case 2:
                        parejas[random_int][2].setnumCapasOcultasString(aux);
                        break;
                    case 3:
                        parejas[random_int][2].setnumEpocasString(aux);
                        break;
                    case 4:
                        parejas[random_int][2].setLearningRateString(aux);
                        break;
                    case 5:
                        parejas[random_int][2].setMomentumString(aux);
                        break;
                }
                i--;
            }
            else{
                rep = random_int;
            }
            temp = "";
            aux = "";
            newString = "";
        }
    }
    // Muta a 2 hijos creados de la cruza que se este realizando
    
    // Realiza la cruza de los individuos de sus atributos (los hiperparámetros de topología) 
    public void cruzar(Individuo[][] parejas,int i){
        Individuo p = new Individuo(); //auxiliar individual for assign it to the matrix
        int n = 0; //getting the middle of the hiperparam
        String temp; //temporal string for "bit exchange"

        //getting just one child per couple
        //each hiperParam gets an one-point crossover
        temp = "";
        //numNeurons
        n = parejas[i][0].getnumNeuronasString().length();
        boolean shortStrin;
        temp = parejas[i][0].getnumNeuronasString().substring(0, (n/2)+1);

        n = parejas[i][1].getnumNeuronasString().length();
        if (n==1){
            temp.concat(Character.toString(parejas[i][1].getnumNeuronasString().charAt(0)));
        }
        else{
            temp.concat(parejas[i][1].getnumNeuronasString().substring((n/2)+1, n));
        }
        p.setnumNeuronasString(temp);

        //HiddenLayers
        n = parejas[i][0].getnumCapasOcultasString().length();
        if (n==1){
            temp = (Character.toString(parejas[i][0].getnumCapasOcultasString().charAt(0)));
        }
        else{
            temp = parejas[i][0].getnumCapasOcultasString().substring(0, n/2);
        }
        n = parejas[i][1].getnumCapasOcultasString().length();
        temp.concat(parejas[i][1].getnumCapasOcultasString().substring((n/2), n));

        p.setnumCapasOcultasString(temp);

        //Epochs
        n = parejas[i][0].getnumEpocasString().length();
        if (n<=2){
            temp = (Character.toString(parejas[i][0].getnumEpocasString().charAt(0)));
        }
        else{
            temp = parejas[i][0].getnumEpocasString().substring(0, (n/2)-1);
        }

        n = parejas[i][1].getnumEpocasString().length();
        if (n==1){
            temp.concat(Character.toString(parejas[i][1].getnumEpocasString().charAt(0)));
        }
        else{
            temp.concat(parejas[i][1].getnumEpocasString().substring((n/2)-1, n));
        }
        p.setnumEpocasString(temp);
        //L.R.
        n = parejas[i][0].getLearningRateString().length();
        if (n==1){
            temp = (Character.toString(parejas[i][0].getLearningRateString().charAt(0)));
        }
        else{
            temp = parejas[i][0].getLearningRateString().substring(0, n/2);
        }
        n = parejas[i][1].getLearningRateString().length();
        temp += (parejas[i][1].getLearningRateString().substring((n/2), n));
        if ((Double.valueOf(Integer.parseInt(temp,2))/100.0+parejas[i][0].getMinLearningRate())
            >=parejas[i][0].getMaxLearningRate()){
            temp = "110";
        }
        else{
            if ((Double.valueOf(Integer.parseInt(temp, 2))/100.0+parejas[i][0].getMinLearningRate())
                <=parejas[i][0].getMinLearningRate()){
                temp = "0";
            }
        }
        p.setLearningRateString(temp);

        //Momentum
        n = parejas[i][0].getMomentumString().length();
        if (n==1){
            temp = (Character.toString(parejas[i][0].getnumNeuronasString().charAt(0)));
        }
        else{
            temp = parejas[i][0].getMomentumString().substring(0, (n / 2));
        }
        n = parejas[i][1].getMomentumString().length();
        temp += (parejas[i][1].getMomentumString().substring((n/2),n));
        if ((Double.valueOf(Integer.parseInt(temp,2))/100.0 + parejas[i][0].getMinMomentum())>=parejas[i][0].getMaxMomentum()){
            temp = "1010";
        }
        else{
            if ((Double.valueOf(Integer.parseInt(temp, 2))/100.0+parejas[i][0].getMinMomentum())<=parejas[i][0].getMinMomentum()){
                temp = "0";
            }
        }
        p.setMomentumString(temp);
        parejas[i][2] = p;
        System.out.println("\tHijo\n\t" + parejas[i][2] + " Creado correctamente " + parejas[i][2].validate() + "\n");
        this.n++;
    }
    // Realiza la cruza de los individuos de sus atributos (los hiperparámetros de topología) 
    
    // Realiza el training y testing de la poblacion
    public void training_testing(){
        System.out.println("Evaluando poblacion");
        try{
            Instances train;
            Evaluation eval;
            FileReader file1,file2;
            for (int i=0; i<n; i++){
                if(generation[i].getAccuracy()==0.0){
                    file1 = new FileReader("train.arff");
                    train = new Instances(file1);
                    train.setClassIndex(train.numAttributes() - 1);
                    mlp.setLearningRate(generation[i].getlearningRateDouble());
                    mlp.setMomentum(generation[i].getMomentumDouble());
                    mlp.setTrainingTime(generation[i].getnumEpocasInt());
                    mlp.setHiddenLayers(generation[i].getnumCapasOcultasString());
                    mlp.setValidationSetSize(1);
                    mlp.buildClassifier(train);
                    file1.close();
                    file2 = new FileReader("test.arff");
                    train = new Instances(file2);
                    train.setClassIndex(train.numAttributes() - 1);
                    eval = new Evaluation(train);
                    eval.evaluateModel(mlp, train);
                    System.out.println("-" + (i + 1) + " " + eval.pctCorrect());
                    generation[i].setAccuracy(eval.pctCorrect());
                    file2.close();
                }
            }
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }
    // Realiza el training y testing de la poblacion

    // Ordena los individuos de acuerdo con su accuracy
    public static void quicksortGeneration(Individuo[] A, int izq, int der){
        Individuo aux,piv = A[izq];
        int i=izq,j=der;
        while (i<j){
            while (A[i].getAccuracy()>=piv.getAccuracy() && i<j){
                i++;
            }
            while (A[j].getAccuracy()<piv.getAccuracy()){
                j--;
            }
            if (i<j){
                aux = A[i];
                A[i] = A[j];
                A[j] = aux;
            }
        }
        A[izq] = A[j];
        A[j] = piv;
        if (izq<(j-1)){
            quicksortGeneration(A,izq,j-1);
        }
        if ((j+1)<der){
            quicksortGeneration(A,j+1,der);
        }
    }
    // Ordena los individuos de acuerdo con su accuracy

    // Elimina los peores 20 individuos
    public void controlPopulation(){
        System.out.println("Controlando poblacion");
        for (int i=this.n-1; i>=30; i--){
            this.generation[i] = new Individuo();
            this.n--;
        }
    }
    // Elimina los peores 20 individuos
    
}
